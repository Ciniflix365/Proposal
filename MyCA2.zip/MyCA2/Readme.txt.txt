Eoin Flood-
When Doing the inaitial Design for the project I went to what i know i best which was notepad++.
From this I was able to do a Fantastic web page & design 
As time was short because a Group memeebr of ours dropped we were already stuck with lots to do & ver little time 
I have not been confident using visual Studio Code Since we started & therefore when time came to use the template i had major problems but I believe I got it working enough with the code thats there just to pass this module 
Hopefully you agree & if have questions about my code please email &  i will get back to ASAP
Thank you for allowing us to go overdue the project date as we had a lot to do with very little time 
Kind Regards 
Eoin Flood 